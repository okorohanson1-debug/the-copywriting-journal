THE COPYWRITING JOURNAL — FIRST WEBSITE BUILD

This is a separate static website starter for a NEW Netlify project. It does not modify Digital Growth Hub.

Included:
- Responsive homepage and article listing
- Three starter articles, each with its own URL
- About, Contact, Privacy and Disclaimer pages
- Selar purchase link: https://selar.com/966192867z
- Basic page titles and descriptions

DEPLOY AS A NEW NETLIFY PROJECT:
1. Sign in to Netlify.
2. Choose Add new site/project, then Deploy manually (labels may vary).
3. Upload the extracted folder contents to the deploy area.
4. Netlify assigns a NEW .netlify.app URL.
5. Keep Digital Growth Hub untouched.

Article URLs:
 /articles/what-is-copywriting.html
 /articles/how-copywriters-earn.html
 /articles/first-copywriting-skills.html

IMPORTANT:
This first build is a public static blog, not yet a working article-admin CMS.
A secure publishing dashboard requires connecting a Git repository and configuring
a CMS/authentication workflow. We should do that after the new Netlify project
exists. The current article art is CSS editorial artwork, not real photographs.
Review all text and customise policies/contact details before public launch.
AdSense approval is not guaranteed and should be considered after the site has
substantial original content, useful navigation and complete disclosures.
